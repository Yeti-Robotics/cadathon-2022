//imports etc
public class DriveCommand {
	//we definitely know what we're doing :thumbs_up:
	
	//initialize etc 
	//left joystick = rotation of robot (in place)
	//right joystick = movement of entire robot (relative to field)
	//swerve module one: move
	//swerve module two: move
	//swerve module three: move
	//swerve module four: move
	//something about motors

}
