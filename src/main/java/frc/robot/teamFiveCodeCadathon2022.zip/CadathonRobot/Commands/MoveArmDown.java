//imports etc
public class MoveArmDown {
	//controlled movement to lower limit when right trigger pressed based on duration (only moves certain speed per second)
}
