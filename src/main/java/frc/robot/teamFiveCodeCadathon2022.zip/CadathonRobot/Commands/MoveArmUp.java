//imports etc

public class MoveArmUp {
	//controlled movement to upper limit when left trigger pressed based on duration (only moves certain speed per second)
}
