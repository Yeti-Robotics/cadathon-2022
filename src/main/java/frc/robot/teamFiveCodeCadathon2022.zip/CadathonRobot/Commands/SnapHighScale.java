//IIIIMMMPOOOOORRRRTTTTTTSSSSS
public class SnapHighScale {
	//snaps arm to position that is best for shooting/placing on high scale
	//will calculate through math, etc and testing (iteration) from position relative to scale
}
