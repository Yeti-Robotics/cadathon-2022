//IIIIMMMPOOOOORRRRTTTTTTSSSSS
public class SnapLowSwitch {
	//snaps arm to position that is best for shooting/placing in low switch
	//will calculate through math, etc and testing (iteration) from position relative to switch
}
