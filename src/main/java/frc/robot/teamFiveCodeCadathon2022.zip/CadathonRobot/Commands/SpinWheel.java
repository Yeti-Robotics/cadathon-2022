//good and cool imports
public class SpinWheel {
	//uses X, only while holding
	//schedule for spinny movement of wheels (to optimum speed determined by PID) to intake

}
