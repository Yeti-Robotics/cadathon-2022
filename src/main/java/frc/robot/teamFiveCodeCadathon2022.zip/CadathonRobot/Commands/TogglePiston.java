//imports imports imports
public class TogglePiston {
	//uses A button
	//if piston is out, pull in
	//if piston is in, pushes piston out to limit to push out cube

}
