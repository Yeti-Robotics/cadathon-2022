
public class Constants {
	/*declare, intialize final constants
	 * motors
	 * solenoids
	 * wheel diameters
	 * shooter important things
	 * speeds, limits
	 * conditional buttons
	 * etc
	 */

}
