
public class Main {
	//main stuff

}
