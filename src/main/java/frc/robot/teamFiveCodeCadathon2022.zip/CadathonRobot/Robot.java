//imports etc
public class Robot {
	//init
	/* AUTONOMOUS
	 * identify alliance we are on
	 * go straight to cross black line
	 * create method of getCubeAndPlace, takes parameters of which side
	 * color sensor for switch
	 * 2 possible paths: going to close side, and going to far side
	 * if color matches on close side, do getCubeAndPlace(closeSide)
	 * if color does not match on close side, do getCubeAndPlace(farSide)
	 * same but in reverse for if we start on other side (have opposite sequences for each side to account for moving
	 to opposite side of field
	 * 
	 */
	//switch to teleop
	//pertinent overrides
}
