//relevant imports
public class armSubsystem {
	//constants and methods relevant to rotation on gear upto limit of where gear ends (90 degrees) in vertical plane
	//we have move up and down commands, as well as snap low and high
}
