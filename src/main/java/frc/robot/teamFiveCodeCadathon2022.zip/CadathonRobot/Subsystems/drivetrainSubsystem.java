//import motors
//import other important things
//import wpilib
//import other necessary things required from other files in robot project

public class drivetrainSubsystem { //extends subsystem base
		//declare motors, gyro
		//initalize and assign motors, invert if necessary
		//configure motors with constants (voltage and other important things)
		//template: motorName = new motorType(constantFile.correctConstant);
		//feedback sensor things if required
		//@Override
		//important braking methods
		//get distance and velocity various encoder functions
		//odometry?
		
}
