//i m p o r t s
public class shooterSubsystem {
	//shooter falcons do falcon things e.g. voltage
	//wheel movement commands
	//piston does out and in
	
}
